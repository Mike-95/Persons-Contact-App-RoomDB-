package com.example.noteapproomdb;

import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import android.os.Looper;

import java.util.logging.LogRecord;

public class AppExecutors {

    //For singleton instantiation
    private static final Object LOCK = new Object();
    private static AppExecutors sInstance;
    private final Executor diskId;
    private final Executor mainThread;
    private final Executor networkId;

    public AppExecutors(Executor diskId, Executor mainThread, Executor networkId) {
        this.diskId = diskId;
        this.mainThread = mainThread;
        this.networkId = networkId;
    }
    public static AppExecutors getInstance(){
        if (sInstance == null){
            synchronized (LOCK){
                sInstance = new AppExecutors(Executors.newSingleThreadExecutor(),
                        Executors.newFixedThreadPool(3),
                        new MainThreadExecutor());
            }
        }
        return sInstance;
    }
    public Executor diskId(){
        return diskId;
    }
    public Executor mainThread() {
        return mainThread;
    }
    public Executor networkId(){
        return networkId;
    }

    private static class MainThreadExecutor implements Executor{
        private Handler mainThreadHandler = new Handler(Looper.getMainLooper());
        @Override
        public void execute(@NonNull Runnable command) {
            mainThreadHandler.post(command);
        }
    }
        }

