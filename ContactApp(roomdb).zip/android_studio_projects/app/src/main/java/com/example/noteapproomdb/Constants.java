package com.example.noteapproomdb;

public class Constants {
    public static final String UPDATE_Person_Id = "update_task";
}
